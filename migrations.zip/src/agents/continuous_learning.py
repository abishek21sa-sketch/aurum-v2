import json
import numpy as np
import pandas as pd
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from src.models.hypothesis import Hypothesis
from src.models.governance import GovernanceRecord, GovernanceStage
from src.models.alpha_registry import AlphaSignal
from src.agents.backtester import (
    fetch_price_data, fetch_vix_data, build_composite_signal,
    run_backtest_with_circuit_breaker, SP500_UNIVERSE
)

def simulate_paper_trading(db: Session, hypothesis: Hypothesis,
                            simulation_days: int = 252) -> dict:
    """
    Simulates forward paper-trading performance by walking the most recent
    `simulation_days` of data (post paper_trading_start, or most recent if
    no real elapsed time exists) and tracking performance against the
    committee's stated risk conditions.
    """
    gov = db.query(GovernanceRecord).filter_by(hypothesis_id=hypothesis.id).first()
    if not gov or gov.current_stage != GovernanceStage.PAPER_TRADING:
        return {"error": "hypothesis is not in paper trading stage"}

    print(f"  Fetching data for paper trading simulation...")
    end = datetime.now().strftime("%Y-%m-%d")
    close, volume = fetch_price_data(SP500_UNIVERSE, "2018-01-01", end)
    vix = fetch_vix_data("2018-01-01", end)

    composite = build_composite_signal(close, volume, hypothesis.signal_components)
    holding_days = hypothesis.expected_holding_days or 21

    # Use the most recent window as the "paper trading period" simulation
    recent_close = close.iloc[-simulation_days:]
    recent_vix = vix.iloc[-simulation_days:]

    print(f"  Running walk-forward simulation over last {simulation_days} trading days...")
    results = run_backtest_with_circuit_breaker(
        composite, recent_close, recent_vix,
        holding_days=holding_days,
        vix_exit_threshold=18.0,
        backtest_start=recent_close.index[0].strftime("%Y-%m-%d")
    )

    if "error" in results:
        return results

    # Check against committee conditions (from debate_record / committee_decision)
    conditions = gov.committee_decision.get("decision") if gov.committee_decision else None
    vix_max_in_window = float(recent_vix.max())
    vix_breach_occurred = vix_max_in_window >= 18.0

    decay_flag = results["sharpe_ratio"] < (hypothesis.sharpe_ratio * 0.5) if hypothesis.sharpe_ratio else False
    retirement_recommended = results["sharpe_ratio"] < 0 or results["max_drawdown"] < -0.35

    learning_report = {
        "simulation_window_days": simulation_days,
        "simulation_start": recent_close.index[0].strftime("%Y-%m-%d"),
        "simulation_end": recent_close.index[-1].strftime("%Y-%m-%d"),
        "paper_sharpe": results["sharpe_ratio"],
        "paper_max_drawdown": results["max_drawdown"],
        "paper_win_rate": results["win_rate"],
        "original_backtest_sharpe": hypothesis.sharpe_ratio,
        "sharpe_degradation": float(round(
            (hypothesis.sharpe_ratio - results["sharpe_ratio"]) / hypothesis.sharpe_ratio, 4
        )) if hypothesis.sharpe_ratio else None,
        "vix_max_observed": round(vix_max_in_window, 2),
        "vix_breach_occurred": vix_breach_occurred,
        "circuit_breaker_triggers": results.get("circuit_breaker_triggers", 0),
        "decay_flag": decay_flag,
        "retirement_recommended": retirement_recommended,
        "evaluated_at": datetime.now(timezone.utc).isoformat()
    }

    # Write back to alpha_registry if it exists, else note we need to register first
    alpha = db.query(AlphaSignal).filter_by(hypothesis_id=hypothesis.id).first()
    if alpha:
        alpha.paper_trading_sharpe = results["sharpe_ratio"]
        alpha.decay_flag = decay_flag
        alpha.retirement_recommended = retirement_recommended
        alpha.last_evaluated_at = datetime.now(timezone.utc)
        db.commit()

    # Update governance with monitoring note
    action = "RETIRE" if retirement_recommended else ("IMPROVE" if decay_flag else "CONTINUE")
    notes = (f"Paper trading simulation ({simulation_days}d window): "
             f"Sharpe {results['sharpe_ratio']} vs backtest {hypothesis.sharpe_ratio}, "
             f"MaxDD {results['max_drawdown']}, VIX max {vix_max_in_window:.1f} "
             f"({'BREACHED' if vix_breach_occurred else 'no breach'}), "
             f"breaker fired {results.get('circuit_breaker_triggers', 0)}x. "
             f"AI recommendation: {action}")

    gov.stage_history = (gov.stage_history or []) + [{
        "from_stage": gov.current_stage,
        "to_stage": gov.current_stage,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "notes": notes
    }]
    db.commit()

    learning_report["recommended_action"] = action
    return learning_report

def print_learning_report(report: dict):
    print(f"\n{'='*65}")
    print(f"CONTINUOUS LEARNING — PAPER TRADING SIMULATION")
    print(f"{'='*65}")
    print(f"Window: {report['simulation_start']} → {report['simulation_end']} "
          f"({report['simulation_window_days']} days)")
    print(f"\nPaper Sharpe       : {report['paper_sharpe']}")
    print(f"Original backtest  : {report['original_backtest_sharpe']}")
    if report['sharpe_degradation'] is not None:
        print(f"Sharpe degradation : {report['sharpe_degradation']*100:.1f}%")
    print(f"Paper max drawdown : {report['paper_max_drawdown']}")
    print(f"Paper win rate     : {report['paper_win_rate']}")
    print(f"\nVIX max observed   : {report['vix_max_observed']}")
    print(f"VIX breach (>=18)  : {report['vix_breach_occurred']}")
    print(f"Circuit breaker fired: {report['circuit_breaker_triggers']}x")
    print(f"\nDecay flag         : {report['decay_flag']}")
    print(f"Retirement rec.    : {report['retirement_recommended']}")
    print(f"\n>>> AI RECOMMENDATION: {report['recommended_action']} <<<")
    print(f"{'='*65}\n")